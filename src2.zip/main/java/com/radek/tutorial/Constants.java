package com.radek.tutorial;

/**
 * Created by Radek on 2017-11-13.
 */

public class Constants {
    public static int SCREEN_WIDTH;
    public static int SCREEN_HEIGHT;
    public static int MAR = 40;
}
